let dash = document.querySelector('.dash');
let menu = document.querySelector('.menu');
let menuList = document.querySelector('.menu_list');

dash.addEventListener('click' , () => {
    menuList.classList.toggle('active')
    menu.classList.toggle('active')
})